export const affairInfo = [
  'student_name',
  'student_id',
  'type',
  'semester',
  'week_num',
  'day_of_week',
  'class_num',
  'reason',
  'study_date',
] as const;

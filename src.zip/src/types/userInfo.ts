export const userInfo = [
  'study_num', //研学次数
  'late_num', //迟到次数
  'early_num', //早退次数
  'absent_num', //缺勤次数
  'leave_num', //请假次数
  'user_id', //学号，或者说id
  'user_name', //姓名
  'user_gender', //性别
  'user_group', //方向
  'user_period', //期数
  'user_email', //邮箱
  'user_phone', //电话
  'user_class', //班级
  'user_major', //专业
  'user_academy', //学院
  'user_introduction', //个性签名
] as const;

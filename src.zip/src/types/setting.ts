// 主题枚举量
export enum theme {
  day,
  night,
}
// 位置枚举量
export enum site {
  top,
  bottom,
  right,
  left,
}

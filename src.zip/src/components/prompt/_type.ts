export type verifysType = (value: string) => {
  reasult: boolean;
  value: string;
};

<style scoped></style>

<template>
  <router-view class="root"></router-view>
</template>

<script lang="ts" setup></script>

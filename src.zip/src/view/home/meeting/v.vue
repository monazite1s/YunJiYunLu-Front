<style scoped lang="scss"></style>

<template>
  <div class="meeting">meeting</div>
</template>

<script lang="ts" setup></script>

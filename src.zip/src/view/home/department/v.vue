<style scoped lang="scss"></style>

<template>
  <div class="department">department</div>
</template>

<script lang="ts" setup></script>

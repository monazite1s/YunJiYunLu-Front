import { RouterInfo } from '@/types/route';

export default {
  path: ':pathMatch(.*)',
} as RouterInfo;
